import ast
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_shell_python_parses():
    ast.parse((ROOT / "tray_shell.py").read_text(encoding="utf-8"))


def test_design_tokens():
    config = json.loads((ROOT / "design-tokens.json").read_text(encoding="utf-8"))
    assert config["name"] == "Tray OS"
    assert config["motionMs"]["rowStagger"] == 30
    assert config["interaction"]["pressScale"] == 0.97


if __name__ == "__main__":
    test_shell_python_parses()
    test_design_tokens()
    print("Tray Shell static checks passed")
