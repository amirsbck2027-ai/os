# Tray OS — Shell Alpha 0.1

Tray OS is a **new desktop-shell project**, with a macOS-inspired design language and real Linux application launching. The Linux kernel and existing drivers remain underneath for hardware compatibility. This alpha is **not** yet an installable replacement for Windows or a complete Wayland compositor.

## Alpha capabilities

- Native GTK application, not a webpage/mockup
- Independently drawn top menu bar and floating animated dock
- Application launcher backed by real `.desktop` applications
- Search, staged list entrance (30ms stagger), click-to-launch
- Clock, quick controls, accent colors, dark/light modes
- Press feedback, ease-out window entrances, minimal 180ms transitions
- Uses limited dependencies and no external inference/service

## Run inside the FORGE/Debian VirtualBox guest

```bash
sudo apt update
sudo apt install python3-gi gir1.2-gtk-3.0 xfconf xfce4-terminal
chmod +x run-tray.sh
./run-tray.sh
```

Run inside a **graphical Xfce login**, not in Windows PowerShell. Press `Ctrl+C` in the terminal to exit. The runner temporarily hides stock Xfce/Plank panels, restores them on exit, and doesn't change boot partitions or display-manager settings. Tray Shell is deliberately not set to autostart until tested in the VM.

## Design

Graphite `#11161A`, raised `#1E262B`, text `#F3F7F5`, secondary `#A5B5B4`, mint `#A5E0C6`. Type from system Sans; 8px spacing grid; touch-friendly 44px buttons. Single accent with controlled feedback. Menus ease out over ~180ms, interactive dock elements ease towards their target size, list entries stagger at 30ms and do not bounce. Reduced-motion mode disables transitional animation.

## Roadmap / blockers

1. Verify this application inside the live VM and iterate visual fidelity.
2. Create actual window-management integration and native notifications.
3. Implement the independent Wayland compositor (window movement, resizing, effects, animations, workspaces, input) and accessibility support.
4. Package a full native app suite, installer, signed security updates and robust rollback.
5. Build and boot-test an installable Tray OS ISO, then test the user's HP physical hardware.

**Not implemented yet:** system-wide window motion/blur/masks/arcs, full accessibility, app store, complete native settings, update server, installer, hardware qualification. The user's 60 motion/design heuristics are requirements for the entire project—not claims about this alpha.
