#!/usr/bin/env python3
"""Tray Shell alpha: lightweight native GTK3 shell surfaces for Linux/X11.

This does not implement a Wayland compositor or replace the window manager.
"""
from __future__ import annotations

import datetime
import os
import shutil
import subprocess
import sys

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gdk, Gio, GLib, Gtk


COLORS = {
    "accent": "#A5E0C6",
    "surface": "#1E262B",
    "canvas": "#11161A",
    "text": "#F3F7F5",
}

CSS = b"""
window.tray-shell, window.tray-popup { background: transparent; }
.tray-bar { background: rgba(19,25,29,0.97); color: #F3F7F5; }
.tray-logo { color: #A5E0C6; font-weight: 800; font-size: 14px; }
.tray-muted { color: #A5B5B4; }
.tray-dock { background: rgba(30,38,43,0.96); border: 1px solid #3C4B4D; border-radius: 19px; padding: 8px; }
button.tray-app, button.tray-bar-button { border: none; box-shadow: none; color: #F3F7F5; background: transparent; border-radius: 13px; padding: 3px; }
button.tray-app:hover, button.tray-bar-button:hover { background: #304047; }
button.tray-app:active, button.tray-bar-button:active { background: #365549; }
.tray-card { background: #1E262B; border: 1px solid #3B474C; border-radius: 18px; color: #F3F7F5; padding: 20px; }
.tray-heading { font-size: 24px; font-weight: 700; }
.tray-hint { font-size: 12px; color: #A5B5B4; }
.tray-search { border: 1px solid #48575A; border-radius: 13px; color: #F3F7F5; background: #303C42; padding: 10px; min-height: 26px; }
button.tray-list-item { color: #F3F7F5; background: transparent; border: none; border-radius: 12px; box-shadow: none; padding: 9px 12px; min-height: 34px; }
button.tray-list-item:hover { background: #2E3C41; }
button.tray-primary { color: #132A20; background: #A5E0C6; border: none; border-radius: 12px; font-weight: bold; min-height: 38px; }
button.tray-primary:hover { background: #C0EEDB; }
"""


def monitor_geometry():
    screen = Gdk.Screen.get_default()
    if screen is None:
        raise RuntimeError("Tray Shell requires a graphical desktop session")
    display = Gdk.Display.get_default()
    monitor = display.get_primary_monitor() if hasattr(display, "get_primary_monitor") else None
    if monitor:
        rect = monitor.get_geometry()
        return rect.x, rect.y, rect.width, rect.height
    rect = screen.get_monitor_geometry(0)
    return rect.x, rect.y, rect.width, rect.height


def clear_container(container):
    for child in list(container.get_children()):
        container.remove(child)


def themed_button(icon, tooltip, callback, size=36):
    button = Gtk.Button()
    button.get_style_context().add_class("tray-app")
    image = Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.DIALOG)
    image.set_pixel_size(size)
    button.add(image)
    button.set_size_request(48, 48)
    button.set_tooltip_text(tooltip)
    button.connect("clicked", lambda *_: callback())
    return button, image


def desktop_launch(info):
    try:
        info.launch([], None)
    except GLib.Error as error:
        print(f"Could not launch {info.get_name()}: {error}", file=sys.stderr)


class FadeWindow(Gtk.Window):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        screen = self.get_screen()
        visual = screen.get_rgba_visual() if screen else None
        if visual is not None:
            self.set_visual(visual)
        self.set_app_paintable(True)
        self.set_decorated(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_keep_above(True)
        self.get_style_context().add_class("tray-popup")
        self._animation_source = None

    def fade_in(self):
        self.show_all()
        if os.environ.get("TRAY_REDUCE_MOTION") == "1":
            self.set_opacity(1)
            return
        self.set_opacity(0)
        elapsed = [0]

        def frame():
            elapsed[0] += 16
            progress = min(1.0, elapsed[0] / 180)
            self.set_opacity(1 - (1 - progress) ** 3)
            if progress >= 1:
                self._animation_source = None
            return progress < 1

        if self._animation_source is not None:
            GLib.source_remove(self._animation_source)
        self._animation_source = GLib.timeout_add(16, frame)


class Launcher(FadeWindow):
    def __init__(self):
        super().__init__(title="Tray Launcher")
        self.set_default_size(530, 510)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_type_hint(Gdk.WindowTypeHint.DIALOG)
        self.connect("key-press-event", self.on_key)
        self.connect("focus-out-event", lambda *_: self.hide())
        frame = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        frame.get_style_context().add_class("tray-card")
        self.add(frame)
        heading = Gtk.Label(label="Find anything", xalign=0)
        heading.get_style_context().add_class("tray-heading")
        frame.pack_start(heading, False, False, 0)
        self.search = Gtk.SearchEntry()
        self.search.set_placeholder_text("Search installed applications")
        self.search.get_style_context().add_class("tray-search")
        self.search.connect("changed", lambda *_: self.populate())
        frame.pack_start(self.search, False, False, 0)
        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.rows = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        scroller.add(self.rows)
        frame.pack_start(scroller, True, True, 0)
        hint = Gtk.Label(label="ESC to close  ·  Open your applications instantly", xalign=0)
        hint.get_style_context().add_class("tray-hint")
        frame.pack_start(hint, False, False, 0)
        self.apps = sorted((a for a in Gio.AppInfo.get_all() if a.should_show()), key=lambda a: a.get_name().casefold())

    def on_key(self, _widget, event):
        if event.keyval == Gdk.KEY_Escape:
            self.hide()
            return True
        return False

    def populate(self):
        clear_container(self.rows)
        term = self.search.get_text().casefold().strip()
        matches = [app for app in self.apps if term in app.get_name().casefold()][:16]
        for index, app in enumerate(matches):
            reveal = Gtk.Revealer()
            reveal.set_transition_type(Gtk.RevealerTransitionType.SLIDE_DOWN)
            reveal.set_transition_duration(140)
            button = Gtk.Button()
            button.get_style_context().add_class("tray-list-item")
            line = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            icon = app.get_icon()
            if icon:
                line.pack_start(Gtk.Image.new_from_gicon(icon, Gtk.IconSize.DIALOG), False, False, 0)
            line.pack_start(Gtk.Label(label=app.get_name(), xalign=0), True, True, 0)
            button.add(line)
            button.connect("clicked", lambda _btn, item=app: (desktop_launch(item), self.hide()))
            reveal.add(button)
            self.rows.pack_start(reveal, False, False, 0)
            reveal.show_all()
            GLib.timeout_add(index * 30 + 1, lambda widget=reveal: (widget.set_reveal_child(True), False)[1])
        self.rows.show_all()

    def present_launcher(self):
        self.search.set_text("")
        self.populate()
        self.fade_in()
        self.present()
        self.search.grab_focus()


class QuickControls(FadeWindow):
    def __init__(self):
        super().__init__(title="Tray Controls")
        self.set_default_size(310, 250)
        self.connect("focus-out-event", lambda *_: self.hide())
        container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        container.get_style_context().add_class("tray-card")
        self.add(container)
        title = Gtk.Label(label="Control Center", xalign=0)
        title.get_style_context().add_class("tray-heading")
        container.pack_start(title, False, False, 0)
        self.status = Gtk.Label(label="System controls", xalign=0)
        self.status.get_style_context().add_class("tray-hint")
        container.pack_start(self.status, False, False, 0)
        for label, cmd in (("Dark appearance", ["xfconf-query", "-c", "xsettings", "-p", "/Net/ThemeName", "-s", "Adwaita-dark"]),
                           ("Light appearance", ["xfconf-query", "-c", "xsettings", "-p", "/Net/ThemeName", "-s", "Adwaita"]),
                           ("Open system settings", ["xfce4-settings-manager"])):
            btn = Gtk.Button(label=label)
            btn.get_style_context().add_class("tray-list-item")
            btn.connect("clicked", lambda _b, command=cmd: self.run_action(command))
            container.pack_start(btn, False, False, 0)

    def run_action(self, command):
        if not shutil.which(command[0]):
            self.status.set_text("This setting is unavailable on this device")
            return
        try:
            subprocess.Popen(command)
            self.status.set_text("Action opened")
        except OSError:
            self.status.set_text("Unable to start action")


class TrayShell:
    def __init__(self):
        self.x, self.y, self.width, self.height = monitor_geometry()
        self.launcher = Launcher()
        self.controls = QuickControls()
        self.bar = FadeWindow(title="Tray Bar")
        self.bar.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.bar.set_default_size(self.width, 40)
        self.bar.move(self.x, self.y)
        self.bar.get_style_context().add_class("tray-shell")
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        row.get_style_context().add_class("tray-bar")
        row.set_border_width(5)
        self.bar.add(row)
        logo = Gtk.Button(label="◈  tray")
        logo.get_style_context().add_class("tray-bar-button")
        logo.get_style_context().add_class("tray-logo")
        logo.connect("clicked", lambda *_: self.launcher.present_launcher())
        row.pack_start(logo, False, False, 10)
        app_name = Gtk.Label(label="Workspace")
        row.pack_start(app_name, False, False, 0)
        filler = Gtk.Box()
        row.pack_start(filler, True, True, 0)
        self.clock = Gtk.Label()
        row.pack_start(self.clock, False, False, 8)
        controls = Gtk.Button(label="●  ●  ●")
        controls.get_style_context().add_class("tray-bar-button")
        controls.connect("clicked", self.open_controls)
        row.pack_start(controls, False, False, 9)
        self.tick_clock()
        GLib.timeout_add_seconds(15, self.tick_clock)

        self.dock = FadeWindow(title="Tray Dock")
        self.dock.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.dock.set_keep_above(True)
        self.dock.get_style_context().add_class("tray-shell")
        self.icons = []
        dock_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        dock_row.get_style_context().add_class("tray-dock")
        self.dock.add(dock_row)
        entries = [
            ("view-app-grid-symbolic", "Applications", lambda: self.launcher.present_launcher()),
            ("system-file-manager-symbolic", "Files", lambda: self.launch(["thunar"])),
            ("web-browser-symbolic", "Browser", lambda: self.launch(["firefox-esr"])),
            ("utilities-terminal-symbolic", "Terminal", lambda: self.launch(["xfce4-terminal"])),
            ("preferences-system-symbolic", "Settings", lambda: self.launch(["xfce4-settings-manager"])),
        ]
        for icon, name, action in entries:
            button, img = themed_button(icon, name, action)
            dock_row.pack_start(button, False, False, 0)
            state = {"button": button, "image": img, "size": 36.0, "target": 36.0}
            button.connect("enter-notify-event", lambda _w, _e, s=state: s.update(target=42.0))
            button.connect("leave-notify-event", lambda _w, _e, s=state: s.update(target=36.0))
            self.icons.append(state)
        dock_width = len(entries) * 56 + (len(entries) + 1) * 8 + 2
        self.dock.set_default_size(dock_width, 74)
        self.dock.move(self.x + (self.width - dock_width) // 2, self.y + self.height - 91)
        GLib.timeout_add(16, self.animate_dock)

    def tick_clock(self):
        self.clock.set_text(datetime.datetime.now().strftime("%a %d %b   %H:%M"))
        return True

    def launch(self, cmd):
        if shutil.which(cmd[0]):
            subprocess.Popen(cmd)

    def open_controls(self, *_):
        self.controls.move(self.x + self.width - 340, self.y + 48)
        self.controls.fade_in()
        self.controls.present()

    def animate_dock(self):
        if os.environ.get("TRAY_REDUCE_MOTION") == "1":
            for item in self.icons:
                item["size"] = item["target"]
                item["image"].set_pixel_size(int(item["size"]))
            return True
        for item in self.icons:
            item["size"] += (item["target"] - item["size"]) * 0.3
            item["image"].set_pixel_size(int(item["size"]))
        return True

    def run(self):
        self.bar.show_all()
        self.dock.show_all()
        Gtk.main()


def main():
    if Gdk.Display.get_default() is None:
        raise SystemExit("Tray Shell needs an active Linux desktop/X11 session")
    css = Gtk.CssProvider()
    css.load_from_data(CSS)
    Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    shell = TrayShell()
    shell.run()


if __name__ == "__main__":
    main()
