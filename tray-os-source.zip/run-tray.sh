#!/usr/bin/env bash
# Temporarily show Tray Shell instead of Xfce's stock panels; restore them on exit.
set -Eeuo pipefail
project="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
had_panel=0
had_plank=0
if pgrep -x xfce4-panel >/dev/null 2>&1; then had_panel=1; fi
if pgrep -x plank >/dev/null 2>&1; then had_plank=1; fi

restore_session() {
  if (( had_panel )); then xfce4-panel >/dev/null 2>&1 & fi
  if (( had_plank )); then plank >/dev/null 2>&1 & fi
}
trap restore_session EXIT

if (( had_panel )); then xfce4-panel --quit >/dev/null 2>&1 || true; fi
if (( had_plank )); then pkill -x plank >/dev/null 2>&1 || true; fi
python3 "$project/tray_shell.py"
