# FORGE OS visual + interaction specification

## Foundation

- Style: quiet, premium, minimal; one mint accent, generous grouping, no badges except actionable status.
- Palette: Canvas `#11171C`, raised `#202A30`, hover `#43585C`, accent `#9CD8BF`, primary text `#F0F5F3`, secondary `#B8C8C8`.
- Typography: Inter; 10 pt system default on Xfce, 27 px section titles. Tabular numerals for measurements and status.
- Spacing: 4 px base, 8/12/16/24 px rhythm. Outer radius 16 px; inner radius adjusted for content inset.
- Icons: Papirus family, consistent stroke/visual size. One prominent action per view.
- Layout: status at top, apps in dock, centered content cards, no desktop-icon clutter. Native task switching and window resize preserved.

## Interaction targets

| Requirement | Design target | Current implementation |
| --- | --- | --- |
| Ease-out entrances, slow in/out | 180–220 ms, easing by context | GTK stack crossfade 180 ms; other windows use Xfce defaults |
| Dropdowns and popovers | 150–250 ms, 0.95 → 1 scale | Pending custom shell implementation |
| Press feedback | 0.97 scale, held states avoid tweens | GTK active color states; scale pending custom shell |
| Exit timing | 20% shorter than entrance | Pending custom shell |
| Row reveal | 30 ms stagger and overlap | Pending custom shell |
| Spatial continuity | Trigger-based entry/exit, arc movement | Pending custom shell |
| Exaggerated feedback | Only for meaningful confirmations | Simple confirmation dialog implemented |
| Reduced motion | Disable nonessential transitions when requested | Pending accessible preference integration |
| Large hit targets and Fitts's law | >= 40–44 px controls | Control Center buttons min-height 38 px plus padding |
| Hick's and Miller's laws | Maximum four main settings categories | Four categories implemented |
| Jakob's law | Familiar window controls and shortcuts | Native Xfce window manager |
| Postel's law | Tolerant input, safe and reversible settings | Basic UI; validation remains |
| Frequency of use | High-frequency functions one interaction away | Dock, familiar task switching and app launch |
| Loading state / Doherty threshold | Immediate acknowledgement, nonblocking work | Threaded package check + status text |
| Motion personality (squash, stretch, anticipation, arcs, follow-through) | Reserved for expressive, nonroutine interactions | Not implemented in Xfce compositor |

## Explicit limitation

All 40 requested principles are accounted for as *specifications*, but they cannot all be enforced system-wide with Xfce GTK CSS. To achieve exact animation mechanics for every window, launcher and dialog, FORGE needs a separately engineered compositor/window shell; this developer preview is not that shell.
