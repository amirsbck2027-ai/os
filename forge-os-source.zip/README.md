# FORGE OS — Developer Preview 0.1

FORGE OS is a **Debian 13 (Trixie) Xfce-based live/installable Linux distribution**, not a newly written kernel and not yet a hardware-certified Windows replacement. This repository is configured to produce **one installer ISO with the desktop and applications preloaded**, using Debian `live-build`. It includes a restrained dark desktop, custom wallpaper, dock, curated apps, conservative performance tuning, security updates and automatic first-login theming.

## Requirements

- x86-64 laptop, recommended 4 GB RAM or more, 30 GB available storage
- Debian 13 build host with `live-build`, `debootstrap`, `xorriso`, `squashfs-tools` and network access to Debian repositories
- At least 15 GB free build storage and 8 GB USB drive

## Build

```bash
sudo apt update
sudo apt install live-build debootstrap xorriso squashfs-tools
./scripts/build.sh
```

Output: `build/live-image-amd64.hybrid.iso` (when the build succeeds). Boot the USB in **Live** mode before installing. ISO builds require root privileges for some filesystem operations. A first build can take tens of minutes and download several GB.

The ISO package list includes the Debian Calamares installer and Debian installer settings. Booting the ISO and selecting **Install** should install the included desktop and applications without a separate FORGE customization step. This path has **not yet been end-to-end validated**.

The desktop defaults are preseeded in `/etc/skel` and XDG autostart runs `/usr/local/bin/forge-first-login` in both Live and installed Xfce sessions. The system-wide autostart is important because Debian Live may create its demo user differently from Calamares-created accounts.

### Build automatically via GitHub Actions

The included `.github/workflows/build-iso.yml` builds in a Debian 13 container on a hosted runner. You must put the *contents* of this project at the root of a GitHub repository, then run **Actions → FORGE OS ISO build → Run workflow**. Download the `FORGE-OS-ISO-parts` artifact. The large ISO is split for transport: extract every part into one directory, copy `scripts/reassemble-iso.ps1` into that directory, then run `./reassemble-iso.ps1` from PowerShell. The reassembler refuses to overwrite existing images and verifies SHA-256.

The workflow is a *build recipe*, not a completed, boot-tested image. This project has not been uploaded to your GitHub account and the workflow has not been run. Network availability, runner storage limits, exact package resolution and UEFI boot compatibility are unverified.

## Alternative: use the official Debian Live ISO (no custom ISO build required)

This is the practical path while the FORGE ISO is unverified. Download Debian 13 **Live Xfce** from https://www.debian.org/CD/live/, boot it and verify hardware. After installing Debian and signing in, extract the FORGE project ZIP and run:

```bash
cd forge-os
sudo ./scripts/apply-to-debian.sh
```

Log out and back in. The script installs the FORGE desktop tools, wallpaper and update configuration on an existing Debian Xfce installation. It **does not** change partitions or install a bootloader. It asks for an explicit confirmation before installing packages and files. This route is **customized Debian**, not a separate ISO, and remains subject to hardware verification.

## Updates

- Debian's signed repositories supply the kernel, browser, system, firmware packages and security maintenance. `unattended-upgrades` handles routine automatic updates; its defaults for allowed trusted origins are preserved. Automatic forced reboots are disabled.
- **FORGE Control Center → Updates** checks installed package metadata and starts an administrator-authorized, fixed system update command.
- Major Debian upgrades are deliberately **manual**, since they can break drivers and require migration steps. FORGE OS branding and custom UI files currently update **only through a newer project build**, not via a dedicated signed FORGE repository. That repository and rollback mechanism are future work.
- Flatpak app updates are separate from APT and can be managed through Software; full background Flatpak update automation has not been validated.

See [HP-INSTALL.md](HP-INSTALL.md) for device-specific instructions, and [DESIGN-SYSTEM.md](DESIGN-SYSTEM.md) for visual and animation implementation status.

## Windows → FORGE OS: safe migration

1. Back up personal files and your Windows BitLocker recovery key to separate storage. Check that the backup opens.
2. Download/prepare the FORGE ISO after building it; use a dedicated USB flash drive. Writing the ISO **erases that USB**.
3. In Windows, disable Fast Startup; suspend BitLocker/device encryption for changes involving boot configuration, following Microsoft's guidance. Never delete a recovery partition without confirming recovery media.
4. Boot the USB using the laptop's firmware boot menu. Choose **Live** (do not install yet). Test Wi-Fi, Bluetooth, sound, camera, keyboard, touchpad, display brightness, sleep/wake, charging and external monitor.
5. Open the graphical installer only after all critical devices work and your data is backed up. Select the correct internal disk by capacity and model.
6. To **replace Windows**, choose an entire-disk installation only after explicitly confirming the internal disk and understanding that this destroys Windows and its data. To **keep Windows**, use a reviewed dual-boot partitioning plan; do not guess partitions.
7. Reboot, install available updates, retest laptop functions and restore data.

We cannot validate HP 14s-cf2xxx or Lenovo Yoga 6 13ABR8 hardware from a cloud container; a real USB boot is mandatory before any disk erasure.

## Honest compatibility limits

- Linux apps: native. Windows programs: some work through Wine/Proton; not guaranteed. macOS apps: not natively supported.
- Microsoft Office desktop, Adobe apps, proprietary anti-cheat games and some device utilities may require Windows.
- This preview does not yet implement a custom graphical shell, rollback engine, encrypted installer workflow or comprehensive accessibility audit.
- Xfce animations are intentionally limited: basic compositing and snappy fades, but not every custom spring/morph/arc transition on the user's list. Those require a dedicated compositor/shell implementation.

## Design specifications

Dark graphite `#11151A`, surfaces `#1B2229`, restrained mint `#9CD8BF`, text `#F1F5F3`, secondary text `#AAB5B6`. Accessible targets 40–44 px where practical; 150–220 ms popovers; reduced-motion-aware future shell. Single panel with grouped launchers and no unnecessary desktop icons.

## Project layout

`config/` contains live-build package selections and system overlay. `scripts/build.sh` builds the image. `scripts/verify.sh` checks structural invariants and catches mistakes before building. The system overlay is copied into the live system by live-build; **nothing in these scripts repartitions or deletes laptop disks**.
