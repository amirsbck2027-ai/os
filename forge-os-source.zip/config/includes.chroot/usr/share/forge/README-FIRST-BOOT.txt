Welcome to FORGE OS.

The Debian installer creates your normal user account. After first login:

  • Open FORGE Control Center from the application launcher.
  • Open Software to find and install more applications.
  • Check Wi-Fi, Bluetooth, sound, brightness and suspend/resume.
  • Open FORGE Control Center → Updates to install system upgrades.

Automatic security updates are configured through Debian unattended-upgrades.
Major Debian release upgrades and the FORGE-specific desktop configuration
remain separately managed; consult documentation before changing major versions.
