# Installing FORGE OS on HP 14s-cf2xxx (Windows 11)

**Do not erase Windows until FORGE OS has a built, validated ISO and the laptop has passed the Live USB checklist.** The cloud project ZIP is not an ISO and cannot be flashed directly.

## 1 — On your HP, while still using Windows

1. Back up `Desktop`, `Documents`, `Downloads`, browser bookmarks, photos and anything in `C:\Server` or other important folders to an external drive. Confirm you can open files on the backup.
2. Keep a Windows recovery USB or reinstall plan. Save the Windows licence details if needed.
3. Search **Manage BitLocker** or **Device encryption**. Record the recovery key if encryption is enabled. Windows boot changes can trigger recovery.
4. Verify the HP internal SSD model and size in **Disk Management**. Photograph the partition layout before considering replacement.
5. If Windows currently works and you need the HP as a 24/7 server, temporarily continue using Windows until network support is confirmed in Linux.

## 2 — Build the ISO (separate Debian/Linux computer or VM)

1. Download `FORGE-OS-developer-preview.zip` and extract it.
2. On a Debian 13 build machine, run `sudo apt update && sudo apt install live-build debootstrap xorriso squashfs-tools`.
3. Inside the extracted `forge-os` project run `sudo ./scripts/build.sh`.
4. Wait for `build/live-image-amd64.hybrid.iso`. Do not continue if the build reports errors.
5. Calculate the ISO SHA-256 with `sha256sum build/live-image-amd64.hybrid.iso` and retain it for later verification.

**Faster alternative:** Download the official Debian 13 **Live Xfce** ISO at https://www.debian.org/CD/live/. Boot and install Debian, then apply the FORGE project using `sudo ./scripts/apply-to-debian.sh` from inside the extracted project. The official ISO is already published; only the FORGE customization code is our developer preview.

## 3 — Create a bootable USB in Windows

1. Use a spare USB drive of at least 8 GB; its contents will be erased.
2. Download Rufus from https://rufus.ie/.
3. In Rufus, select **the USB drive**, then select the `.iso` (not the `.zip`).
4. For UEFI hardware, use the default suggested settings; carefully verify the device capacity/name before clicking **Start**.
5. Do not choose the laptop's internal SSD as a target.

## 4 — Live-test on the HP first

1. Shut down the HP, insert the USB, and power it on while tapping **Esc** repeatedly.
2. Press **F9** for Boot Device Options. Select the USB's UEFI boot entry.
3. Choose **Live** mode, not Install. Booting Live should not modify internal-drive partitions.
4. Complete the checklist below. Record device failures, particularly the RTL8821CE Wi-Fi adapter. Your HP previously showed Windows Code 45 for this device; a Linux installation cannot fix disconnected or failed physical hardware.

## 5 — Install only after successful testing

Run the Debian graphical installer included in the built ISO. Review the installer summary twice. If you choose **Erase disk / use entire disk**, all Windows partitions on that selected disk are deleted. Only proceed with a verified backup and recovery plan. If dual-booting, seek a partition-by-partition review; do not improvise while encrypted Windows volumes are present.

## First boot checklist

| Check | Pass criteria |
| --- | --- |
| Boot | Reboots without USB and reaches login |
| Network | Stable Wi-Fi or Ethernet and DNS resolution |
| Audio | Speakers and microphone work |
| Graphics | Correct display resolution, brightness, video playback |
| Input | Keyboard, touchpad, mouse, USB ports |
| Power | Charging, lid events, suspend/resume |
| Peripherals | Bluetooth, camera, HDMI |
| Update | `sudo apt update` succeeds; FORGE Control Center opens |
| Security | Screen lock works; unattended upgrades configured |

**No-go:** unstable storage, missing networking, repeated boot errors, overheating, or inability to restore Windows. Keep Windows until resolved.
