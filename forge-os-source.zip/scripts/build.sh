#!/usr/bin/env bash
set -Eeuo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_dir"

if [[ "$(id -u)" -ne 0 ]]; then
  echo 'Run as root: sudo ./scripts/build.sh' >&2
  exit 1
fi
if ! command -v lb >/dev/null 2>&1; then
  echo 'Install live-build first: sudo apt install live-build debootstrap xorriso squashfs-tools' >&2
  exit 1
fi

./scripts/verify.sh
mkdir -p build/config
cp -a config/. build/config/
cd build
lb config \
  --distribution trixie \
  --architectures amd64 \
  --binary-images iso-hybrid \
  --debian-installer live \
  --archive-areas 'main contrib non-free non-free-firmware' \
  --bootappend-live 'boot=live components quiet splash' \
  --iso-application 'FORGE OS Developer Preview' \
  --iso-publisher 'FORGE OS Project' \
  --iso-volume 'FORGE_OS'
lb build
iso_path="$project_dir/build/live-image-amd64.hybrid.iso"
[[ -s "$iso_path" ]] || { echo 'Build finished without a nonempty ISO.' >&2; exit 1; }
if command -v xorriso >/dev/null 2>&1; then
  xorriso -indev "$iso_path" -report_el_torito plain >/dev/null 2>&1 || {
    echo 'ISO verification failed; do not flash this image.' >&2
    exit 1
  }
fi
(cd "$project_dir/build" && sha256sum live-image-amd64.hybrid.iso > live-image-amd64.hybrid.iso.sha256)
echo "ISO written to: $iso_path"
echo 'This is a structural image check only. Hardware boot testing is still mandatory.'
