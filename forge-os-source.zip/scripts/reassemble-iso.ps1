# For Windows: after extracting the GitHub Actions artifact into one directory,
# reassemble binary ISO parts in numeric order and verify the SHA-256 checksum.
$ErrorActionPreference = 'Stop'
$parts = @(Get-ChildItem -LiteralPath . -Filter 'FORGE-OS.iso.part-*' -File | Sort-Object Name)
if ($parts.Count -lt 1) { throw 'No ISO parts found in this directory.' }
$destination = Join-Path (Get-Location).Path 'live-image-amd64.hybrid.iso'
if (Test-Path -LiteralPath $destination) { throw "Refusing to overwrite existing ISO: $destination" }
$stream = [System.IO.File]::Open($destination, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write)
try {
  foreach ($part in $parts) {
    $source = [System.IO.File]::OpenRead($part.FullName)
    try { $source.CopyTo($stream) }
    finally { $source.Dispose() }
  }
} finally { $stream.Dispose() }
$shaFile = 'live-image-amd64.hybrid.iso.sha256'
if (!(Test-Path $shaFile)) { throw 'Missing checksum file; ISO cannot be verified.' }
$expected = ((Get-Content $shaFile -Raw).Trim() -split '\s+')[0].ToUpperInvariant()
$actual = (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash.ToUpperInvariant()
if ($expected -ne $actual) { throw 'ISO SHA-256 mismatch. Do NOT use this image.' }
Write-Host 'FORGE OS ISO reassembled and checksum verified:' $destination
