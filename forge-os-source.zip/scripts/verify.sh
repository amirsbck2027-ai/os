#!/usr/bin/env bash
set -Eeuo pipefail
root_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
required=(
  'config/package-lists/forge.list.chroot'
  'config/includes.chroot/etc/skel/.config/autostart/forge-first-login.desktop'
  'config/includes.chroot/usr/local/bin/forge-first-login'
  'config/includes.chroot/usr/share/backgrounds/forge/forge-wallpaper.svg'
  'config/includes.chroot/etc/apt/apt.conf.d/52unattended-upgrades-local'
  'config/includes.chroot/usr/local/bin/forge-control'
  'config/includes.chroot/usr/local/sbin/forge-upgrade'
)
for rel in "${required[@]}"; do
  [[ -s "$root_dir/$rel" ]] || { echo "Missing or empty: $rel" >&2; exit 1; }
done
bash -n "$root_dir/scripts/build.sh"
bash -n "$root_dir/scripts/apply-to-debian.sh"
bash -n "$root_dir/config/includes.chroot/usr/local/bin/forge-first-login"
bash -n "$root_dir/config/includes.chroot/usr/local/sbin/forge-upgrade"
python3 - "$root_dir/config/includes.chroot/usr/local/bin/forge-control" <<'PY'
import ast
import pathlib
import sys
ast.parse(pathlib.Path(sys.argv[1]).read_text(encoding='utf-8'))
PY
if grep -nE '(mkfs\.|parted |wipefs |dd if=)' "$root_dir/scripts/build.sh"; then
  echo 'Unexpected disk-writing command in build scripts' >&2
  exit 1
fi
echo 'FORGE OS structural checks passed.'
