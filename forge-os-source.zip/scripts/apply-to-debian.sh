#!/usr/bin/env bash
# Install the FORGE desktop on a fresh Debian 13 Xfce system.
# This DOES NOT repartition disks or replace a running operating system.
set -Eeuo pipefail

root_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ "$(id -u)" -ne 0 ]]; then
  echo 'Run as root from installed Debian 13: sudo ./scripts/apply-to-debian.sh' >&2
  exit 1
fi

if ! grep -q '^VERSION_CODENAME=trixie$' /etc/os-release; then
  echo 'This installer is only supported on Debian 13 (trixie).' >&2
  exit 1
fi

if ! command -v xfce4-session >/dev/null 2>&1; then
  echo 'Install Debian with the Xfce desktop environment first.' >&2
  exit 1
fi

echo 'FORGE installs desktop assets and packages; it does not erase your disk.'
echo 'It will update APT software and can overwrite matching FORGE-owned files.'
read -r -p 'Type APPLY to continue: ' approval
[[ "$approval" == 'APPLY' ]] || { echo 'Cancelled.'; exit 1; }

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y \
  xfce4-whiskermenu-plugin xfce4-pulseaudio-plugin xfce4-taskmanager \
  xfce4-screenshooter thunar-archive-plugin network-manager-gnome \
  papirus-icon-theme fonts-inter plank python3-gi gir1.2-gtk-3.0 \
  polkitd pkexec unattended-upgrades zram-tools flatpak \
  gnome-software gnome-software-plugin-flatpak

source_dir="$root_dir/config/includes.chroot"
install -d /usr/local/bin /usr/local/sbin /usr/share/applications /usr/share/backgrounds/forge /usr/share/forge
install -m 0755 "$source_dir/usr/local/bin/forge-control" /usr/local/bin/forge-control
install -m 0755 "$source_dir/usr/local/bin/forge-first-login" /usr/local/bin/forge-first-login
install -m 0755 "$source_dir/usr/local/sbin/forge-upgrade" /usr/local/sbin/forge-upgrade
install -m 0644 "$source_dir/usr/share/applications/forge-control.desktop" /usr/share/applications/forge-control.desktop
install -m 0644 "$source_dir/usr/share/backgrounds/forge/forge-wallpaper.svg" /usr/share/backgrounds/forge/forge-wallpaper.svg
install -m 0644 "$source_dir/usr/share/forge/plank.desktop" /usr/share/forge/plank.desktop
install -d /etc/apt/apt.conf.d /etc/default
install -m 0644 "$source_dir/etc/apt/apt.conf.d/52unattended-upgrades-local" /etc/apt/apt.conf.d/52unattended-upgrades-local
install -m 0644 "$source_dir/etc/apt/apt.conf.d/53forge-upgrade-policy" /etc/apt/apt.conf.d/53forge-upgrade-policy

# Preserve existing per-machine zram customization when present.
if [[ ! -e /etc/default/zramswap ]]; then
  install -m 0644 "$source_dir/etc/default/zramswap" /etc/default/zramswap
fi

# Configure the user who invoked sudo, without changing any existing panel/dock settings.
target_user="${SUDO_USER:-}"
if [[ -n "$target_user" && "$target_user" != root ]] && id "$target_user" >/dev/null 2>&1; then
  user_home="$(getent passwd "$target_user" | cut -d: -f6)"
  if [[ -d "$user_home" ]]; then
    install -d -o "$target_user" -g "$(id -gn "$target_user")" "$user_home/.config/autostart"
    install -m 0644 -o "$target_user" -g "$(id -gn "$target_user")" \
      "$source_dir/etc/skel/.config/autostart/forge-first-login.desktop" \
      "$user_home/.config/autostart/forge-first-login.desktop"
  fi
fi

echo 'FORGE desktop applied. Log out and log in again; open FORGE Control Center from the app launcher.'
